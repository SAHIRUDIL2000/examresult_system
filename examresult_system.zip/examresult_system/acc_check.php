<?php 
session_start(); 
include "dbcon.php";

if (isset($_POST['regno']) && isset($_POST['password'])
    && isset($_POST['repass'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$regno = validate($_POST['regno']);
	$password = validate($_POST['password']);
    $repass = validate($_POST['repass']);


	$user_data = 'regno='. $regno;



	if (empty($regno)){
		header("Location: Stuacc.php?error=User Name is required&$user_data");
	    exit();
	}else if(empty($password)){
        header("Location: Stuacc.php?error=Password is required&$user_data");
	    exit();
	}
	else if(empty($repass)){
        header("Location: Stuacc.php?error=Re Password is required&$user_data");
	    exit();
	}
    else if($password !== $repass){
        header("Location: Stuacc.php?error=The confirmation password  does not match&$user_data");
	    exit();
	}

	else{

		// hashing the password
        $password = md5($password);

	    $sql = "SELECT * FROM stuaccount WHERE regno='$regno' ";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location: Stuacc.php?error=The username is taken try another&$user_data");
	        exit();
		}else {
           $sql2 = "INSERT INTO stulogin(regno,password) VALUES('$regno', '$password')";
           $result2 = mysqli_query($conn, $sql);
           if ($result2) {
           	 header("Location: Stuacc.php?success=Your account has been created successfully");
	         exit();
           }else {
	           	header("Location: Stuacc.php?error=unknown error occurred&$user_data");
		        exit();
           }
		}
	}


	
}else{
	header("Location: Stuacc.php");
	exit();
}

