<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="css/bootstrap.css">

</head>
<body>
    <div class="rounded-5 border border-2 border-dark" style="margin-top:10px; margin-left:10px; margin-right:10px;"> 
    <table class="table table-borderless">
      
          <tr>
            <th scope="col"><img src="c.jpg" alt="" style="width:150px; margin-top:5px; margin-left:5px;"></th>
            <th scope="col"> <div style="text-align:center; margin-right:10px;">
                <div> <h1>University of Vavuniya Sri Lanka</h1></div>
                     <div><h1>Faculty of Technological Studies</h1> </div>
                     <div><h3>Exam Results 2018/2019</h3> </div>
                 </div> </th>
            <th scope="col"><img src="c.jpg" alt="" style="width:150px; margin-top:20px;"></th>
           </tr>
        
    </table>
 
  
</div>   
</div>
 
<div>
    <img src="A.png" alt="" style="width: 25px; margin-top:5px; margin-left:5px;"><img src="H.png" alt="" style="width:25px; margin-top:5px; margin-left:5px;">
<table class="table">
<tr><td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2">Student Details</td>
            </tr>
            <tr>
                <td><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name"></td>
            </tr>
            <tr>
                <td><label for="Tel">Tel No:</label></td>
                <td><input type="text" id="Tel" name="Tel"></td>
            </tr>
            <tr>
                <td><label for="email">Email:</label></td>
                <td><input type="text" id="email" name="email"></td>
            </tr>
            <tr>
                <td><label for="reg">Reg No:</label></td>
                <td><input type="text" id="reg" name="reg"></td>
            </tr>
            <tr>
                <td><label for="password">Password:</label></td>
                <td><input type="text" id="password" name="password"></td>
            </tr>
            <tr>
                <td><label for="index">Index No:</label></td>
                <td><input type="text" id="index" name="index"></td>
            </tr>
            <tr>
                <td colspan="2"><button type="button">ADD</button></td>
            </tr>
        </table>
    </form>
</td>
<td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2"><label for="Reg">Enter Registration Number</label><input type="text" id="Reg" name="Reg"></td>
            </tr>
            <tr>
                <td><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name"></td>
            </tr>
            <tr>
                <td><label for="Tel">Tel No:</label></td>
                <td><input type="text" id="Tel" name="Tel"></td>
            </tr>
            <tr>
                <td><label for="email">Email:</label></td>
                <td><input type="text" id="email" name="email"></td>
            </tr>
            <tr>
                <td><label for="reg">Reg No:</label></td>
                <td><input type="text" id="reg" name="reg"></td>
            </tr>
            <tr>
                <td><label for="password">Password:</label></td>
                <td><input type="text" id="password" name="password"></td>
            </tr>
            <tr>
                <td><label for="index">Index No:</label></td>
                <td><input type="text" id="index" name="index"></td>
            </tr>
            <tr>
                <td colspan="2"><button type="button">Edit</button><button type="button">Delete</button></td>
            </tr>
        </table>
    </form>
</td></tr>
<tr><td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2">Staff Details</td>
            </tr>
            <tr>
                <td><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name"></td>
            </tr>
            <tr>
                <td><label for="Id">Id:</label></td>
                <td><input type="text" id="Id" name="Id"></td>
            </tr>
            <tr>
                <td><label for="email">Email:</label></td>
                <td><input type="text" id="email" name="email"></td>
            </tr>
           
            <tr>
                <td><label for="password">Password:</label></td>
                <td><input type="text" id="password" name="password"></td>
            </tr>
            
            <tr>
                <td colspan="2"><button type="button">ADD</button></td>
            </tr>
        </table>
    </form>
</td>
<td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2"><label for="Reg">Enter Staff Id</label><input type="text" id="Reg" name="Reg"></td>
            </tr>
            <tr>
                <td><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name"></td>
            </tr>
            <tr>
                <td><label for="Id">Id:</label></td>
                <td><input type="text" id="Id" name="Id"></td>
            </tr>
            <tr>
                <td><label for="email">Email:</label></td>
                <td><input type="text" id="email" name="email"></td>
            </tr>
           
            <tr>
                <td><label for="password">Password:</label></td>
                <td><input type="text" id="password" name="password"></td>
            </tr>
            
            <tr>
                <td colspan="2"><button type="button">Edit</button><button type="button">Delete</button></td>
            </tr>
        </table>
    </form>
</td></tr>
<tr><td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2">Subject Details</td>
            </tr>
            <tr>
                <td><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name"></td>
            </tr>
            <tr>
                <td><label for="Code">Subject Code:</label></td>
                <td><input type="text" id="Code" name="Code"></td>
            </tr>
            
            <tr>
                <td colspan="2"><button type="button">ADD</button></td>
            </tr>
        </table>
    </form>
</td>
<td>
    <form>
        <table >
            <tr>
                <td colspan="2"><label for="Reg">Enter Staff Id</label><input type="text" id="Reg" name="Reg"></td>
            </tr>
            <tr>
                <td><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name"></td>
            </tr>
            <tr>
                <td><label for="Code">Subject Code:</label></td>
                <td><input type="text" id="Code" name="Code"></td>
            </tr>
            
            <tr>
                <td colspan="2"><button type="button">Edit</button><button type="button">Delete</button></td>
            </tr>
        </table>
    </form>
</td></tr>
<tr><td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2">Result Details</td>
            </tr>
            <tr>
                <td><label for="index">Index No:</label></td>
                <td><input type="text" id="index" name="index"></td>
            </tr>
             <tr>
                <td><label for="reg">Reg No:</label></td>
                <td><input type="text" id="reg" name="reg"></td>
            </tr>
             <tr>
                <td><label for="Code">Subject Code:</label></td>
                <td><input type="text" id="Code" name="Code"></td>
            </tr>
            <tr>
                <td><label for="Grade">Grade:</label></td>
                <td><input type="text" id="Grade" name="Grade"></td>
            </tr>
            
            <tr>
                <td colspan="2"><button type="button">ADD</button></td>
            </tr>
        </table>
    </form>
</td>
<td>
    <form>
        <table class="table">
            <tr>
                <td colspan="2"><label for="Reg">Enter Staff Id</label><input type="text" id="Reg" name="Reg"></td>
            </tr>
            <tr>
                <td><label for="index">Index No:</label></td>
                <td><input type="text" id="index" name="index"></td>
            </tr>
             <tr>
                <td><label for="reg">Reg No:</label></td>
                <td><input type="text" id="reg" name="reg"></td>
            </tr>
             <tr>
                <td><label for="Code">Subject Code:</label></td>
                <td><input type="text" id="Code" name="Code"></td>
            </tr>
            <tr>
                <td><label for="Grade">Grade:</label></td>
                <td><input type="text" id="Grade" name="Grade"></td>
            </tr>
            
            <tr>
                <td colspan="2"><button type="button">Edit</button><button type="button">Delete</button></td>
            </tr>
        </table>
    </form>
</td></tr>
</table>
</div>
 
</body>
<footer class="text-center text-lg-start bg-dark text-white">
   
    <section class="">
      <div class="container text-center text-md-start mt-5" >
        <!-- Grid row -->
        <div class="row mt-3" >
          <!-- Grid column -->
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4" style="margin-top:10px;">
            <!-- Content -->
            <h6 class="text-uppercase fw-bold mb-4">
              <i class="fas fa-gem me-3"></i>
            </h6>
            <p>
                Dean,<br>
                Faculty of Technological Studies,<br>
                University of Vavuniya,<br>
                Pampaimadu,<br>
                Vavuniya, Sri Lanka<br>
                Tel :   +94 24 222 2265<br>
                Fax :   +94 24 222 2265<br>
            </p>
          </div>
          
          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4" style="margin-top:10px;">
           
        <iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4826.827166110597!2d80.39654131667454!3d8.756519333333012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xaa4502ed3daa62db!2sUniversity%20of%20Vavuniya%20Hostel!5e0!3m2!1sen!2slk!4v1629056582941!5m2!1sen!2slk" width="300px" height="200px" allowfullscreen="" margin-right="20px"></iframe>
          </div>
          
          
        
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4" style="margin-top:10px;">
            <!-- Links -->
            <h6 class="text-uppercase fw-bold mb-4"></h6>
            
            <p>
              <i class="fas fa-envelope me-3"></i>
              e-mail : exams@vau.ac.lk
            </p>
            <p><i class="fas fa-phone me-3"></i> Tel : 024 22 23317</p>
            <p><i class="fas fa-print me-3"></i> Fax : 024 22 23317</p>
          </div>
          </div>
     
      </div>
    </section>
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
        Copyright © 2021 University of Vavuniya.
      
    </div>
   
  </footer>
</html>