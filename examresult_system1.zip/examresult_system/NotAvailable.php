<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="css/bootstrap.css">

</head>
<body>
    <div class="rounded-5 border border-dark" style="margin-top:10px; margin-left:10px; margin-right:10px;"> 
    <table class="table">
      
          <tr>
            <th scope="col"><img src="c.jpg" alt="" style="width:150px; margin-top:20px; margin-left:35px;"></th>
            <th scope="col"> <div style="text-align:center; margin-right:10px;">
                <div> <h1>UNIVERSITY OF VAVUNIYA SRI LANKA</h1></div>
                     <div><h1>Faculty of Technological Studies</h1> </div>
                     <div><h2>Exam Results</h2> </div>
                 </div> </th>
            <th scope="col"><img src="c.jpg" alt="" style="width:150px; margin-top:20px;"></th>
           </tr>
        
    </table>
 </div> 
<br>
 <div class="container" style="text-align:center;">
    <h2>Result Not Available</h2>
       
    
  </div>
</body>
</html>














