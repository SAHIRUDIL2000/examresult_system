<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="css/bootstrap.css">

</head>
<body>

<div class="container" style="margin-right:50px;">

<!--<div style="width:970px; height:1200px; padding:20px; text-align:center; border: 10px solid #787878">-->
<div style="width:700px; height:900px; padding:20px; text-align:center; border: 5px solid #787878">
<img src="./logo.png" class="mx-auto d-block" alt="" style="width:120px; height:100px; margin-bottom:10px; margin-top:10px;">
       <span style="font-size:16px;"><h3><u>UNIVERSITY OF VAVUNIYA SRI LANKA</u></h3></span>
       <div>
       <table style="margin-left:90px; text-align:justify;">
       <tr><td>Name</td><td>:-</td></tr>
       <tr><td>Registration No</td><td>:-</td></tr>
       <tr><td>Index No</td><td>:-</td></tr>
</table>
</div><br>
       <span style="font-size:18px"><b><u>Faculty of Technological Studies</u></b></span>
       <br>
       <span style="font-size:18px"><u>First Examination in Information Communication Technology-2019</u></span> <br/>
       <span style="font-size:18px"><u>First Semester-January 2022</u></span> <br/>
      <p>The grades of marks obtained by you in each unit offered for this examination are given below.</p>
      
  <div>    <table class="table table-bordered" style="width:600px;">
        <tr><th>No.</th><th style="padding-right:auto">Subject</th><th>Subject Code</th><th>Grade</th></tr>
        <tr><th>1</th><th style="">Fundamentals of web programming</th><th>TICT1142</th><th>B</th></tr>
        <tr><th>2</th><th style="padding-right:auto">Subject</th><th>Subject Code</th><th>Grade</th></tr>
        <tr><th>3</th><th style="padding-right:auto">Subject</th><th>Subject Code</th><th>Grade</th></tr>
</table>
</div>
<br>
<!--<div class="square square-lg border border-dark" style="width:150px; height:30px;"><i>Semester GPA:</i></div>-->


<div class="container">
    <div class="row"><div class="col" style="margin-top:30px; text-align:justify;">
    Prepared by:
    <br><br>
    Date: - 
<br><br><br>

    <table style="margin-top:10px; font-size:10px;">
        <u><font-size="10px">Key to the grading</u>
<tr><td >A+</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">85-100</td>
<td style="padding-left:20px;"></td> <td>C</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">50-54</td></tr>
        
<tr><td >A</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">80-84</td>
<td style="padding-left:20px;"></td> <td>C-</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">45-49</td></tr>

<tr><td >A-</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">75-79</td>
<td style="padding-left:20px;"></td> <td>D+</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">40-44</td></tr>

<tr><td >B+</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">70-74</td>
<td style="padding-left:20px;"></td> <td>D</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">35-39</td></tr>

<tr><td >B</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">65-69</td>
<td style="padding-left:20px;"></td> <td>E</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">00-34</td></tr>

<tr><td >B-</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">60-64</td>
<td style="padding-left:20px;"></td> <td>Ab</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">Absent</td></tr>

<tr><td >C+</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">55-59</td>
<td style="padding-left:20px;"></td> <td>MC</td><td style="padding-left:5px;">--</td><td style="padding-left:5px;">Medical</td></tr>
</table>
    
</div>
<div class="col" style="margin-top:30px;">

Checked by:<br><br>
       
     ................................  <br>
       (K.Gnanalasharan)<br>
      Deputy registrar,<br>
    Examination and Student Admission
</div>
</div>
</div>
<br><br>
<p><b>NB:</b>  Students are requested to preserve this statement carefully, as no duplicate will be issued under any circumstance</p>
</div>
</div>
</div>












</body>
</html>