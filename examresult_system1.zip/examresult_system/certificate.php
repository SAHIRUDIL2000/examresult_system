<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="css/bootstrap.css">

</head>
<body>
    <form>
        <div class="form-group" style="margin-left:10px;">
    <div class="mx-auto d-block"> <center>
  <img src="logo.png" alt="" style="width:150px; margin-top:70px; margin-left:35px;"></center></div>
            <div class="mx-auto d-block" style="text-align:center; margin-right:10px;">
                <h2><u>University of Vavuniya Sri Lanka</u></h2></div>
  
<div style="margin-left:100px; margin-top:20px;">
<table>
<tr>
        <th style="padding:10%;">Name</th>
        <th>:-</th>
        <th ></th>
      </tr>

      <tr>
        <th style="padding:10%;">Registration No</th>
        <th>:-</th>
        <th></th>
      </tr>
      <tr>
        <th style="padding:10%;">Index No</th>
        <th>:-</th>
        <th></th>
      </tr>
    </table>
</div>
<div style="text-align:center;">
<div> <h4>Faculty of Technological Studies</h4></div>
        <div style="text-size:45px;">First Examination in Information Communication Technology 2019</div>
                     <div>First semester-January 2022</div></div>
                 
 <p style="margin-left:100px;">The grades of marks obtained by you in each unit offered for this examination are given below:</p>                    
















</form>
</div>

</body>
</html>